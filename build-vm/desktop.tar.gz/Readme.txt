
================
Steps to Follow
================

* Start the terminal
* Change the current directory to the tool's directory
	$ cd /home/phantm/Desktop/phantm/
* This folder now contains the source code and the JAR file that I built for the tool Phantm
* Run Phantm to analyze the PHP file (as explained in Phantm_tool_paper.pdf)
	$ java -jar target/phantm-assembly-1.0.7.jar ../test_data/test_file.php

	You can see that the tool analyzes this code and gives out the following error:
	---------------------------------------------------------------------------------------
	/home/phantm/Desktop/phantm/../test_data/test_file.php:7  Notice: Type mismatch: expected: Array["file" => Resource, ...], found: 		Array["file" => Resource or False, ...]
	$content = fread($conf["file"]);

	1 notice and 0 error occured.
	---------------------------------------------------------------------------------------

	As you can see that this is the error message that the tool's paper shows as well
* Run Phantm to analyze the correct PHP file (based on the suggestions made by the tool)
	$ java -jar target/phantm-assembly-1.0.7.jar ../test_data/correct_file.php

	And you will notice that the errors have been fixed
	---------------------------------------------------------------------------------------
	0 notice and 0 error occured.
	---------------------------------------------------------------------------------------

* This shows that the tool is working as described in the paper (Phantm_tool_paper.pdf).
